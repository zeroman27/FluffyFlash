//
//  ListCommand.swift
//  Mist
//
//  Created by Nindi Gill on 26/8/21.
//

import ArgumentParser

struct ListCommand: ParsableCommand {
    static var configuration: CommandConfiguration = .init(
        commandName: "list",
        abstract: "List all macOS Firmwares / Installers available to download.",
        subcommands: [ListFirmwareCommand.self, ListInstallerCommand.self]
    )
}
